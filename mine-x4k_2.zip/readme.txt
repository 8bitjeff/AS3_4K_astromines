Mine-X 4K

The game is in the /bin folder

Mine-X 4K is an Asteroids / Geometry Wars variant. I know, not too original, but I attempted to squeeze as much in as possible. The game is built completely in Actionscript with no external assets. It employs a completely blit game screen and pixel perfect collision detection.   

Instructions: Zoom around the 360 degree scrolling play field, Asteroids style, and blast all of the fast moving mines in each sector. Use the radar screen to see the entire sector. You can even use it to blast mines off screen. All of the enemy, missiles and particles are also displayed on the radar. You only get one ship, so be very careful.

Keys: Arrows to move (rotate left and right and thrust with up) and space bar fires.

Compilation:
Included is the Flash Develop project to compile.  The project should be usable out of the box, but if you need to re-compile with your own project and just the main.as class, you will need to add 

-raw-metadata " 

To the compiler options to ensure that  it stays under 4K.  
Obviously, please let me know if you can't get it to compile under 4K

The source is freely available for distribution.

Game by:
Jeff Fulton
jeff@8bitrocket.com
www.8bitrocket.com


